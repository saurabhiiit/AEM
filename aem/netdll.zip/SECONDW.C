/* time.f -- translated by f2c (version of 23 April 1993  18:34:30).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/



#include "windows.h"
//#include "MAPIDEFS.H"

#include "f2c.h"

/* Table of constant values */



doublereal second_(void)
{

int ret;
static doublereal lasttime=0.;
doublereal timeelapsed,now;

union {FILETIME la;__int64  lo;} tcreat,texit,tuser,tkernel;
HANDLE pH= GetCurrentProcess();
ret=GetProcessTimes(pH,&tcreat.la,&texit.la,&tuser.la,&tkernel.la);

if(!ret) puts("Fehler in GetProcessTimes\n");

//return time in seconds since start
now= ((doublereal)tuser.lo+(doublereal)tkernel.lo)*1e-7; // 1 unit = 100 ns
timeelapsed= (now /* - lasttime*/  );
lasttime=now;
return timeelapsed;
}

doublereal dsecnd_(void)
{

return second_();
}

